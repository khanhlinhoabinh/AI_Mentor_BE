package com.aimentor.ai_mentor_be.controller;

import com.aimentor.ai_mentor_be.dto.ActivityLogResponse;
import com.aimentor.ai_mentor_be.service.ActivityLogService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/activity-logs")
@RequiredArgsConstructor
public class ActivityLogController {

    private final ActivityLogService service;

    @GetMapping
    public List<ActivityLogResponse> getLatestLogs() {
        return service.getLatestLogs();
    }
}